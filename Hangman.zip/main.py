import random
import requests
file_path = 'english3.txt'

print("Welcome to Hangman")
print("\n--------------------------")

wordDict = []

  #Copies words from text file into the word list
with open(file_path, 'r') as file:
    content = file.read()
    words = content.split()
    wordDict.extend(words)

playagain = -5

  #Contrstuction of the stages of Hangman
def print_man(wrong):
    if(wrong == 0):
        print("\n +---+")
        print(" |   |")
        print("     |")
        print("     |")
        print("     |")
        print("     |")
        print("===========")
    elif (wrong == 1):
        print("\n +---+")
        print(" |   |")
        print(" O   |")
        print("     |")
        print("     |")
        print("     |")
        print("===========")
    elif (wrong == 2):
        print("\n +---+")
        print(" |   |")
        print(" O   |")
        print(" |   |")
        print("     |")
        print("     |")
        print("===========")
    elif (wrong == 3):
        print("\n +---+")
        print(" |   |")
        print(" O   |")
        print(r"/|   |")
        print("     |")
        print("     |")
        print("===========")
    elif (wrong == 4):
        print("\n +---+")
        print(" |   |")
        print(" O   |")
        print(r"/|\  |")
        print("     |")
        print("     |")
        print("===========")
    elif (wrong == 5):
        print("\n +---+")
        print(" |   |")
        print(" O   |")
        print(r"/|\  |")
        print("/    |")
        print("     |")
        print("===========")
    elif (wrong == 6):
        print("\n +---+")
        print(" |   |")
        print(" O   |")
        print(r"/|\  |")
        print(r"/ \  |")
        print("     |")
        print("===========")

#Writes the blanks based on the randomWord
def printWord(guessedLetters):
    display_word = ""
    for char in randomWord:
        if char in guessedLetters:
            #if character is guessed, fill it in
            display_word += char + " "
        else:
            #If character hasn't been guessed put underscore
            display_word += "_ "
    print(display_word)

while playagain != "1": #loops until player quites
    status = 404
    while status == 404:  #Generates a word until it has a proper definition using https://dictionaryapi.dev/ API
        randomWord = random.choice(wordDict)
        response = requests.get(f"https://api.dictionaryapi.dev/api/v2/entries/en/{randomWord}")
        if response.status_code == 200:
           status +=1

    lettersGuessed = []
    wrongGuess = 0

    print_man(wrongGuess)
    while wrongGuess < 6: #Loops until player exceeds 6 turns in which case they lose
        print("\nLetters Guessed:")
        print(' '.join(lettersGuessed))
        printWord(lettersGuessed)

        letterChoice = input("\nGuess a Letter: ").lower() #guarantees every entry will act the same

        if letterChoice in lettersGuessed:
            print("You already guessed that letter.")
            print_man(wrongGuess)
            continue

        if letterChoice in randomWord:
            lettersGuessed.append(letterChoice)
            print_man(wrongGuess)
        else:
            wrongGuess += 1
            lettersGuessed.append(letterChoice)
            print_man(wrongGuess)

        if set(randomWord) <= set(lettersGuessed):
            break

    print("\nThe word was:", randomWord)
    if wrongGuess < 6:
        print("Congratulations, you guessed the word!")
    else:
        print("Game over. Better luck next time.")
    define = input("Would you like the definition?\n0:yes\n1:no\n")
    if define == "0":
        response = requests.get(f"https://api.dictionaryapi.dev/api/v2/entries/en/{randomWord}") #Gets the definition through https://dictionaryapi.dev/ API
        if response.status_code == 200:
            data = response.json()
            if data:
                meaning = data[0]['meanings'][0]['definitions'][0]['definition']
                print(f"Definition of '{randomWord}': {meaning}")
            else:
                print("No definition found.")
        else:
            # Error Handling for API
            print("Error fetching definition.")
            print("Status Code:", response.status_code)
            print("Response Content:", response.text)
    # Prompts player to play again
    playagain = input("Would you like to play again?\n0:yes\n1:no\n")
print("Have a great day!")